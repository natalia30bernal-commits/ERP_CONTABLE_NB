import React, { useMemo, useState } from 'react'
import { 
  LayoutDashboard, Users, CalendarDays, FileText, Wallet, BriefcaseBusiness,
  HeartPulse, Building2, ClipboardList, FolderOpen, BarChart3, Settings,
  Plus, Edit, Trash2, Power, PowerOff, Download, Search
} from 'lucide-react'
import { jsPDF } from 'jspdf'
import './styles/app.css'

const modules = [
  ['Panel Principal', LayoutDashboard],
  ['CRM Clientes', Users],
  ['Calendario Inteligente', CalendarDays],
  ['Cuentas de Cobro', FileText],
  ['Cartera', Wallet],
  ['Mis Finanzas Personales', Wallet],
  ['Obligaciones Tributarias', ClipboardList],
  ['Gestión Humana Integral', BriefcaseBusiness],
  ['SG-SST', HeartPulse],
  ['ESAL y RTE', Building2],
  ['Cierre Contable y Gerencial', BarChart3],
  ['Gestión Documental', FolderOpen],
  ['Reuniones y Tareas', CalendarDays],
  ['Reportes', BarChart3],
  ['Portal Cliente', Users],
  ['Configuración', Settings],
]

const initialClients = [
  {
    id: 'CLI-001',
    razon: 'TEJIDOS NURO S.A.S.',
    nit: '900000001',
    tipo: 'Persona Jurídica',
    clasificacion: ['Responsable IVA', 'Facturador Electrónico', 'Nómina Electrónica'],
    estado: 'Activo'
  },
  {
    id: 'CLI-002',
    razon: 'CORPORACIÓN ARTE CIMA',
    nit: '901696076-4',
    tipo: 'ESAL',
    clasificacion: ['ESAL RTE', 'Exógena'],
    estado: 'Activo'
  }
]

function Badge({children, tone='blue'}) {
  return <span className={`badge ${tone}`}>{children}</span>
}

function CrudButtons() {
  return (
    <div className="crud">
      <button><Plus size={15}/> Crear</button>
      <button><Edit size={15}/> Modificar</button>
      <button><Trash2 size={15}/> Eliminar</button>
      <button><Power size={15}/> Activar</button>
      <button><PowerOff size={15}/> Inactivar</button>
      <button><Download size={15}/> Exportar PDF</button>
    </div>
  )
}

function Dashboard() {
  const kpis = [
    ['Clientes activos', '2'],
    ['Obligaciones próximas', '14'],
    ['Tareas pendientes', '8'],
    ['Cuentas por cobrar', '$3.500.000'],
    ['Cartera vencida', '$1.000.000'],
    ['Ingresos mes', '$5.800.000'],
    ['Cumplimiento tributario', '82%'],
    ['Alertas críticas', '3'],
  ]
  return (
    <>
      <div className="hero">
        <div>
          <h1>ERP CONTABLE NB</h1>
          <p>Plataforma Integral para Contadores Independientes</p>
        </div>
        <img src="/logo-nb.png" alt="Logo Natalia Bernal" />
      </div>
      <CrudButtons />
      <div className="grid">
        {kpis.map(([label, value]) => (
          <div className="card" key={label}>
            <span>{label}</span>
            <strong>{value}</strong>
          </div>
        ))}
      </div>
      <div className="panel">
        <h2>Centro de Control Tributario 360°</h2>
        <p>Clientes, obligaciones, cuentas de cobro, cartera, gestión humana, ESAL, documentos, reportes y calendario conectados en un solo sistema.</p>
      </div>
    </>
  )
}

function Clientes() {
  return (
    <>
      <div className="section-title">
        <h1>CRM Clientes / Hoja de Vida</h1>
        <div className="search"><Search size={16}/><input placeholder="Buscar cliente, NIT o clasificación"/></div>
      </div>
      <CrudButtons />
      <div className="panel">
        <h2>Clasificación Tributaria Especial Inteligente</h2>
        <div className="checks">
          {['Persona Natural','Persona Jurídica','SAS','ESAL','Fundación','Responsable IVA','No Responsable IVA','SIMPLE','Agente Retención','Autorretenedor','Gran Contribuyente','Facturador Electrónico','Nómina Electrónica','Documento Soporte','Exógena','ESAL RTE','ZOMAC'].map(x => (
            <label key={x}><input type="checkbox"/> {x}</label>
          ))}
        </div>
      </div>
      <table>
        <thead>
          <tr><th>ID</th><th>Cliente</th><th>NIT</th><th>Tipo</th><th>Clasificación</th><th>Estado</th></tr>
        </thead>
        <tbody>
          {initialClients.map(c => (
            <tr key={c.id}>
              <td>{c.id}</td><td>{c.razon}</td><td>{c.nit}</td><td>{c.tipo}</td>
              <td>{c.clasificacion.map(x => <Badge key={x}>{x}</Badge>)}</td>
              <td><Badge tone="green">{c.estado}</Badge></td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  )
}

function CuentaCobro() {
  const [status, setStatus] = useState('Generada')
  const generatePdf = () => {
    const doc = new jsPDF()
    doc.setFillColor(12, 48, 120)
    doc.rect(0, 0, 210, 28, 'F')
    doc.setTextColor(255,255,255)
    doc.setFontSize(18)
    doc.text('CUENTA DE COBRO - ERP CONTABLE NB', 15, 18)
    doc.setTextColor(0,0,0)
    doc.setFontSize(12)
    doc.text('Cliente: CORPORACIÓN ARTE CIMA', 15, 45)
    doc.text('Concepto: Asesoría contable y tributaria', 15, 55)
    doc.text('Periodo: Junio 2026', 15, 65)
    doc.text('Valor bruto: $1.000.000', 15, 75)
    doc.text('Retenciones: $0', 15, 85)
    doc.text('Valor neto a recibir: $1.000.000', 15, 95)
    doc.text('Estado: ' + status, 15, 110)
    doc.save('cuenta-cobro-nb.pdf')
  }
  return (
    <>
      <h1>Cuentas de Cobro / Asesorías</h1>
      <CrudButtons />
      <div className="panel two">
        <div>
          <h2>Cuenta de Cobro No. CC-2026-0001</h2>
          <p><strong>Cliente:</strong> CORPORACIÓN ARTE CIMA</p>
          <p><strong>Concepto:</strong> Asesoría contable y tributaria</p>
          <p><strong>Valor neto:</strong> $1.000.000</p>
          <p><strong>Estado sincronizado:</strong> <Badge>{status}</Badge></p>
          <button className="primary" onClick={generatePdf}>Generar PDF Premium NB</button>
        </div>
        <div>
          <h2>Integración automática</h2>
          <p>Al generar PDF se crea ingreso en Mis Finanzas Personales, registro de cartera, flujo de caja e historial del cliente.</p>
          <select value={status} onChange={e=>setStatus(e.target.value)}>
            {['Generada','Enviada','Abono Parcial','Pagada','Anulada'].map(s => <option key={s}>{s}</option>)}
          </select>
        </div>
      </div>
    </>
  )
}

function GenericModule({name}) {
  const items = useMemo(() => ({
    'Calendario Inteligente': ['Día', 'Semana', 'Mes', 'Agenda', 'Tributario', 'Laboral', 'ESAL', 'Operativo'],
    'Cartera': ['Cuentas por cobrar', 'Abonos', 'Clientes morosos', 'Acuerdos de pago', 'Historial de pagos'],
    'Mis Finanzas Personales': ['Ingresos', 'Gastos personales', 'Gastos profesionales', 'Seguridad social', 'Flujo de caja', 'Presupuesto'],
    'Obligaciones Tributarias': ['IVA', 'Retención', 'Renta', 'ICA', 'SIMPLE', 'Exógena', 'Nómina Electrónica'],
    'Gestión Humana Integral': ['Empleados', 'Contratos', 'Nómina', 'Seguridad Social', 'Vacaciones', 'Dotación', 'Expediente Laboral'],
    'SG-SST': ['Política SST', 'Matriz de peligros', 'Matriz legal', 'Plan anual', 'EPP', 'Accidentes', 'Auditorías'],
    'ESAL y RTE': ['Entidades', 'Cumplimiento RTE', 'Registro Web', 'Excedentes', 'Donaciones', 'Memoria Económica'],
    'Cierre Contable y Gerencial': ['Checklist', 'Conciliaciones', 'Impuestos', 'Estados Financieros', 'Indicadores', 'Informe Gerencial'],
    'Gestión Documental': ['Tributarios', 'Contables', 'Laborales', 'Jurídicos', 'Financieros', 'Control de versiones'],
    'Reuniones y Tareas': ['Reuniones', 'Tareas', 'Seguimientos', 'Solicitudes de documentos', 'Historial de actividades'],
    'Reportes': ['Generales', 'Financieros', 'Tributarios', 'Laborales', 'ESAL', 'Gerenciales'],
    'Portal Cliente': ['Obligaciones', 'Subir documentos', 'Reportes', 'Cuentas de cobro', 'Vencimientos'],
    'Configuración': ['Usuarios', 'Roles', 'Permisos', 'Plantillas PDF', 'Supabase', 'Auditoría']
  }), [])
  return (
    <>
      <h1>{name}</h1>
      <CrudButtons />
      <div className="grid">
        {(items[name] || ['Crear', 'Modificar', 'Eliminar', 'Activar', 'Inactivar']).map(x => (
          <div className="card" key={x}><span>{name}</span><strong>{x}</strong></div>
        ))}
      </div>
      <div className="panel">
        <h2>Integraciones del módulo</h2>
        <p>Este módulo se conecta con Cliente, Historial, Calendario, Alertas, Gestión Documental y Reportes Gerenciales, manteniendo trazabilidad por usuario, fecha, hora y módulo origen.</p>
      </div>
    </>
  )
}

export default function App() {
  const [active, setActive] = useState('Panel Principal')
  return (
    <div className="app">
      <aside>
        <div className="brand">
          <img src="/logo-nb.png" alt="NB" />
          <div><strong>ERP CONTABLE NB</strong><span>Natalia Bernal</span></div>
        </div>
        <nav>
          {modules.map(([name, Icon]) => (
            <button className={active === name ? 'active' : ''} onClick={() => setActive(name)} key={name}>
              <Icon size={18}/> {name}
            </button>
          ))}
        </nav>
      </aside>
      <main>
        {active === 'Panel Principal' && <Dashboard />}
        {active === 'CRM Clientes' && <Clientes />}
        {active === 'Cuentas de Cobro' && <CuentaCobro />}
        {!['Panel Principal','CRM Clientes','Cuentas de Cobro'].includes(active) && <GenericModule name={active} />}
      </main>
    </div>
  )
}
